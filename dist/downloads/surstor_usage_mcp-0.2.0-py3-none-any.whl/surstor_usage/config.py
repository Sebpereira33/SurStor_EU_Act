"""Platform-specific, account-isolated state outside the working directory."""
import hashlib
import os
import sys
from pathlib import Path
from .collector import Collector


def data_directory():
    if os.name == 'nt':
        base = Path(os.environ.get('LOCALAPPDATA', Path.home() / 'AppData' / 'Local'))
    elif sys.platform == 'darwin':
        base = Path.home() / 'Library' / 'Application Support'
    else:
        base = Path(os.environ.get('XDG_DATA_HOME', Path.home() / '.local' / 'share'))
    return base / 'surstor-usage'


def configured_collector():
    url = os.environ.get('SURSTOR_USAGE_URL', 'https://www.surstor.net').rstrip('/')
    token = os.environ.get('SURSTOR_USAGE_TOKEN') or os.environ.get('SURSTOR_USAGE_DEVICE_TOKEN', '')
    email = os.environ.get('SURSTOR_USAGE_EMAIL') if not token else None
    password = os.environ.get('SURSTOR_USAGE_PASSWORD') if not token else None
    identity = hashlib.sha256((url + ':' + (email.strip().casefold() if email else token)).encode()).hexdigest()
    queue = os.environ.get('SURSTOR_USAGE_QUEUE', str(data_directory() / identity / 'outbox.sqlite'))
    return Collector(url, token, queue, email=email, password=password)
