"""Metadata-only durable delivery. Credentials never enter the outbox."""
from contextlib import contextmanager
import json
import sqlite3
import time
from pathlib import Path
from urllib.parse import urlsplit
import urllib.request
import urllib.error
from .model import validate, canonical


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *_):
        return None


class ReportingError(ValueError):
    """Safe error text: no submitted values or response bodies."""


def http_error(error):
    messages = {400: 'Bad request.', 401: 'Authentication failed. Check the upload token or credentials.',
                403: 'Access denied.', 409: 'event_id conflicts with stored metadata.',
                413: 'Event exceeds 16384 bytes.', 422: 'Event validation failed.',
                429: 'Rate or workspace limit reached. Retry later.'}
    message = messages.get(error.code, 'Service unavailable. Retry later.')
    # Only forward known field names and a bounded description from the configured server.
    try:
        detail = json.loads(error.read(4096)).get('error', {})
        field = detail.get('field')
        from .model import FIELDS
        if field in FIELDS or field in ('body', 'cost.amount', 'cost.currency', 'cost.kind', 'cost.pricing_version'):
            message += ' Field: ' + field + '. See the event contract.'
    except (ValueError, AttributeError):
        pass
    finally:
        error.close()
    return ReportingError(f'HTTP {error.code}: {message}')


class Collector:
    def __init__(self, url, token, path, *, email=None, password=None):
        parsed = urlsplit(url)
        if parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path not in ('', '/') or not parsed.hostname:
            raise ValueError('Invalid service URL')
        if parsed.scheme != 'https' and not (parsed.scheme == 'http' and parsed.hostname in ('127.0.0.1', '::1')):
            raise ValueError('Remote uploads require HTTPS')
        self.base_url = url.rstrip('/')
        self.credentials = None
        self.expires = 0
        if email or password:
            if not email or not password:
                raise ValueError('Supply both email and password')
            self.credentials = {'email': email, 'password': password}
            token = ''
        if not self.credentials and len(token) < 32:
            raise ValueError('Missing upload token')
        self.url = self.base_url + '/api/events'
        self.token = token
        self.path = str(path)
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.execute("CREATE TABLE IF NOT EXISTS outbox(id TEXT PRIMARY KEY,body TEXT,state TEXT NOT NULL DEFAULT 'pending')")

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=15)
        try:
            with db:
                yield db
        finally:
            db.close()

    def enqueue(self, event):
        event = validate(event)
        body = canonical(event)
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            old = db.execute('SELECT body FROM outbox WHERE id=?', (event['event_id'],)).fetchone()
            if old:
                if old[0] != body:
                    raise ValueError('event_id conflicts with queued metadata')
                return
            if db.execute('SELECT COUNT(*) FROM outbox').fetchone()[0] >= 10000:
                raise ValueError('Local queue full')
            db.execute('INSERT INTO outbox(id,body) VALUES(?,?)', (event['event_id'], body))

    def upload_token(self, opener):
        if self.credentials and time.monotonic() >= self.expires:
            req = urllib.request.Request(self.base_url + '/api/agent-session',
                data=json.dumps(self.credentials).encode(), headers={'Content-Type': 'application/json'})
            with opener.open(req, timeout=10) as response:
                session = json.loads(response.read(4096))
            self.token = session['access_token']
            self.expires = time.monotonic() + int(session['expires_in']) - 30
        return self.token

    def check_connection(self):
        opener = urllib.request.build_opener(NoRedirect())
        try:
            if self.credentials:
                self.expires = 0
                self.upload_token(opener)
                return {'connected': True, 'message': 'Login OK. Upload session valid for 60 minutes.'}
            req = urllib.request.Request(self.base_url + '/api/check-connection', data=b'{}',
                headers={'Authorization': 'Bearer ' + self.token, 'Content-Type': 'application/json'})
            with opener.open(req, timeout=10) as response:
                result = json.loads(response.read(4096))
            if result.get('connected') is not True:
                raise ReportingError('Connection could not be verified.')
            return {'connected': True, 'message': 'Upload token valid. Connection OK.'}
        except urllib.error.HTTPError as error:
            raise http_error(error) from None
        except (OSError, ValueError, KeyError) as error:
            if isinstance(error, ReportingError):
                raise
            raise ReportingError('Could not reach the service or read its response.') from None

    def flush(self):
        sent = 0
        errors = []
        with self.connect() as db:
            rows = db.execute("SELECT id,body FROM outbox WHERE state='pending' ORDER BY rowid LIMIT 100").fetchall()
        opener = urllib.request.build_opener(NoRedirect())
        for event_id, body in rows:
            try:
                token = self.upload_token(opener)
                req = urllib.request.Request(self.url, data=body.encode(),
                    headers={'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json'}, method='POST')
                with opener.open(req, timeout=10) as response:
                    result = json.loads(response.read(4097))
                    if response.status not in (200, 201) or result.get('accepted') is not True:
                        raise ReportingError('Upload was not acknowledged.')
            except urllib.error.HTTPError as error:
                status = error.code
                errors.append(str(http_error(error)))
                if status == 401:
                    self.expires = 0
                if status in (409, 422):
                    with self.connect() as db:
                        db.execute("UPDATE outbox SET state='rejected' WHERE id=?", (event_id,))
                    continue
                break
            except (OSError, ValueError, KeyError):
                errors.append('Upload unavailable. Event remains queued for retry.')
                break
            with self.connect() as db:
                db.execute('DELETE FROM outbox WHERE id=?', (event_id,))
            sent += 1
        with self.connect() as db:
            states = dict(db.execute('SELECT state,COUNT(*) FROM outbox GROUP BY state'))
        result = {'uploaded': sent, 'pending': states.get('pending', 0), 'rejected': states.get('rejected', 0)}
        if errors:
            result['errors'] = list(dict.fromkeys(errors))
        return result
