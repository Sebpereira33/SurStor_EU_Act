"""Claude Code transcript collector. Only allowlisted usage metadata is persisted."""
import hashlib
import json
import sqlite3
import uuid
from pathlib import Path
from .model import validate, canonical, InvalidEvent

REQUEST_NAMESPACE = uuid.UUID('88d2f8c5-e86e-4995-9b55-a809dd47d1c7')


def event_from_entry(entry):
    if entry.get('type') != 'assistant':
        return None
    message = entry.get('message')
    if not isinstance(message, dict) or not isinstance(message.get('usage'), dict):
        return None
    request = entry.get('requestId') or message.get('id')
    if not isinstance(request, str) or not request:
        return None
    usage = message['usage']
    fields = ('input_tokens', 'output_tokens', 'cache_read_input_tokens', 'cache_creation_input_tokens')
    counts = [usage.get(name) for name in fields]
    # Missing cache counts stay unknown; inclusive input cannot then be claimed.
    if any(type(value) is not int or value < 0 for value in counts):
        return None
    input_count, output_count, cache_read, cache_write = counts
    event = validate({
        'version': 1, 'event_id': str(uuid.uuid5(REQUEST_NAMESPACE, request)),
        'occurred_at': entry.get('timestamp'), 'provider': 'anthropic',
        'model': message.get('model'), 'integration': 'claude-code',
        'usage_source': 'harness_event', 'usage_status': 'reported',
        'input_tokens': input_count + cache_read + cache_write, 'output_tokens': output_count,
        'cache_read_tokens': cache_read, 'cache_write_tokens': cache_write, 'cost': None
    })
    return event


def collect(hook, collector):
    if hook.get('hook_event_name') not in ('Stop', 'SubagentStop', 'SessionEnd'):
        return {'collected': 0, 'skipped': 0}
    filename = hook.get('agent_transcript_path') if hook.get('hook_event_name') == 'SubagentStop' else hook.get('transcript_path')
    if not isinstance(filename, str):
        raise ValueError('Hook did not supply a transcript path.')
    path = Path(filename)
    if not path.is_file():
        raise ValueError('Transcript is not available yet.')
    identity = hashlib.sha256(str(path.resolve()).encode()).hexdigest()
    state = sqlite3.connect(collector.path + '.collector.sqlite', timeout=30)
    try:
        with state:
            state.execute('CREATE TABLE IF NOT EXISTS cursors(id TEXT PRIMARY KEY, offset INTEGER, fingerprint TEXT)')
            state.execute('CREATE TABLE IF NOT EXISTS reported(id TEXT PRIMARY KEY, body TEXT)')
            state.execute('BEGIN IMMEDIATE')
            old = state.execute('SELECT offset,fingerprint FROM cursors WHERE id=?', (identity,)).fetchone()
            with path.open('rb') as stream:
                # Stable first-line fingerprint detects truncation/replacement.
                fingerprint = hashlib.sha256(stream.readline()).hexdigest()
                offset = old[0] if old and old[1] == fingerprint and old[0] <= path.stat().st_size else 0
                stream.seek(offset)
                grouped = {}
                skipped = 0
                while True:
                    start = stream.tell()
                    line = stream.readline()
                    if not line:
                        break
                    if not line.endswith(b'\n'):
                        stream.seek(start)
                        break
                    try:
                        entry = json.loads(line)
                        event = event_from_entry(entry)
                        if event:
                            previous = grouped.get(event['event_id'])
                            if previous:
                                event['occurred_at'] = previous['occurred_at']
                            grouped[event['event_id']] = event
                    except (ValueError, TypeError, AttributeError):
                        skipped += 1
                next_offset = stream.tell()
            collected = 0
            for event_id, event in grouped.items():
                previous = state.execute('SELECT body FROM reported WHERE id=?', (event_id,)).fetchone()
                if previous:
                    prior = json.loads(previous[0])
                    event['occurred_at'] = prior['occurred_at']
                    if canonical(event) != canonical(prior):
                        raise InvalidEvent('Repeated request has changed usage. Collector stopped to avoid double-counting.')
                    continue
                collector.enqueue(event)
                state.execute('INSERT INTO reported VALUES(?,?)', (event_id, canonical(event)))
                collected += 1
            state.execute('INSERT OR REPLACE INTO cursors VALUES(?,?,?)', (identity, next_offset, fingerprint))
        return {'collected': collected, 'skipped': skipped}
    finally:
        state.close()
