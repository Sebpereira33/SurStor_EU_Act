import argparse,json,os,secrets,uuid
from pathlib import Path
from .server import make_server

def main():
    parser=argparse.ArgumentParser(description='SurStor Usage Dashboard developer preview')
    parser.add_argument('command',choices=['init','serve']); parser.add_argument('--config',default='.state/config.json'); parser.add_argument('--database',default='.state/usage.sqlite')
    parser.add_argument('--host',default='127.0.0.1'); parser.add_argument('--port',type=int,default=8790); parser.add_argument('--allow-container-network',action='store_true')
    a=parser.parse_args(); path=Path(a.config)
    if a.command=='init':
        path.parent.mkdir(parents=True,exist_ok=True)
        config={'workspaces':[{'id':str(uuid.uuid4()),'name':'My workspace','dashboard_token':secrets.token_urlsafe(48),'devices':[{'id':str(uuid.uuid4()),'name':'First collector','token':secrets.token_urlsafe(48)}]}]}
        fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'w',encoding='utf-8') as stream: json.dump(config,stream,indent=2)
        print('Created private credentials at',path,'— protect this file; do not commit or share it.'); return
    if a.host!='127.0.0.1' and not (a.host=='0.0.0.0' and a.allow_container_network): parser.error('Use loopback or explicitly allow an isolated container bind')
    server=make_server(json.loads(path.read_text(encoding='utf-8')),a.database,a.host,a.port)
    print(f'SurStor Usage Dashboard: http://{a.host}:{a.port}')
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()
if __name__=='__main__': main()
