"""stdio MCP bridge; hosts must supply real usage, never inferred counts."""
import json,os,sys
from .collector import ReportingError
from .model import InvalidEvent
from .model import EVENT_SCHEMA,MAX_BODY
TOOLS=[{'name':'surstor_check_connection','description':'Verify upload credentials without creating a usage event.','inputSchema':{'type':'object','properties':{},'additionalProperties':False}},{'name':'surstor_report_usage','description':'Queue actual request usage metadata. Never guess tokens. No prompts, responses, paths or tool arguments. Input includes cache counts. Reuse the event UUID for retries.','inputSchema':EVENT_SCHEMA},
       {'name':'surstor_flush_usage','description':'Retry pending metadata uploads and return queue counts.','inputSchema':{'type':'object','properties':{},'additionalProperties':False}}]
def run(reader,writer,collector):
    initialized=False
    while True:
        line=reader.readline(MAX_BODY+4097)
        if not line: return
        if len(line)>MAX_BODY+4096:
            while line and not line.endswith('\n'): line=reader.readline(MAX_BODY+4097)
            writer.write(json.dumps({'jsonrpc':'2.0','id':None,'error':{'code':-32700,'message':'Message too large'}})+'\n'); writer.flush(); continue
        request=None
        try:
            request=json.loads(line)
            if not isinstance(request,dict) or request.get('jsonrpc')!='2.0' or not isinstance(request.get('method'),str): raise ValueError()
            method=request['method']; params=request.get('params',{})
            if 'id' not in request: continue
            if method=='initialize':
                version=params.get('protocolVersion')
                if version not in ('2024-11-05','2025-03-26','2025-06-18'): version='2025-06-18'
                result={'protocolVersion':version,'capabilities':{'tools':{}},'serverInfo':{'name':'surstor-usage','version':'0.2.0'}}; initialized=True
            elif method=='ping': result={}
            elif not initialized: raise ValueError()
            elif method=='tools/list': result={'tools':TOOLS}
            elif method=='tools/call':
                try:
                    name=params['name']; args=params.get('arguments',{})
                    if name=='surstor_check_connection' and args=={}:
                        outcome=collector.check_connection()
                    else:
                        if name=='surstor_report_usage': collector.enqueue(args)
                        elif name!='surstor_flush_usage' or args!={}: raise ValueError()
                        outcome=collector.flush()
                    result={'content':[{'type':'text','text':json.dumps(outcome)}],'isError':bool(outcome.get('errors'))}
                except (InvalidEvent, ReportingError) as error:
                    result={'content':[{'type':'text','text':str(error)}],'isError':True}
                except Exception:
                    result={'content':[{'type':'text','text':'Reporting failed. Check the local queue and request format.'}],'isError':True}
            else:
                writer.write(json.dumps({'jsonrpc':'2.0','id':request['id'],'error':{'code':-32601,'message':'Method not found'}})+'\n'); writer.flush(); continue
            response={'jsonrpc':'2.0','id':request['id'],'result':result}
        except Exception: response={'jsonrpc':'2.0','id':request.get('id') if isinstance(request,dict) else None,'error':{'code':-32600,'message':'Invalid request'}}
        writer.write(json.dumps(response)+'\n'); writer.flush()
def main():
    from .cli import main as start
    start()
if __name__=='__main__': main()
