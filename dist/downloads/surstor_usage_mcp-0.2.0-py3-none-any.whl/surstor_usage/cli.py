"""Console entry point and explicit Claude Code hook installer."""
import argparse
import json
import os
from pathlib import Path
import shutil
import sys
from .config import configured_collector
from .collector import ReportingError


def install_hook():
    directory = Path.home() / '.claude'
    directory.mkdir(parents=True, exist_ok=True)
    settings = directory / 'settings.json'
    original = settings.read_text(encoding='utf-8') if settings.exists() else '{}'
    data = json.loads(original)
    executable = Path(sys.executable).resolve()
    # Forward slashes are understood by Claude Code's shell on Windows.
    command = '"' + executable.as_posix() + '" -m surstor_usage.cli collect-claude'
    hooks = data.setdefault('hooks', {})
    changed = False
    for event in ('Stop', 'SubagentStop', 'SessionEnd'):
        groups = hooks.setdefault(event, [])
        if any(h.get('command') == command for group in groups for h in group.get('hooks', [])):
            continue
        groups.append({'hooks': [{'type': 'command', 'command': command, 'async': True, 'timeout': 60}]})
        changed = True
    if changed:
        if settings.exists():
            backup = settings.with_suffix('.json.surstor-backup')
            if not backup.exists():
                shutil.copy2(settings, backup)
        temporary = settings.with_suffix('.json.surstor-tmp')
        temporary.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')
        os.replace(temporary, settings)
    print('Claude Code hooks installed. Export SURSTOR_USAGE_TOKEN in the environment that launches Claude Code, then restart it.')


def main():
    parser = argparse.ArgumentParser(description='SurStor usage reporting over local stdio MCP.')
    parser.add_argument('--check', action='store_true', help='Check credentials without writing an event')
    parser.add_argument('command', nargs='?', choices=('install-hook', 'collect-claude'))
    parser.add_argument('host', nargs='?', choices=('claude-code',))
    args = parser.parse_args()
    try:
        if args.command == 'install-hook':
            if args.host != 'claude-code':
                parser.error('Use install-hook claude-code')
            install_hook()
            return
        collector = configured_collector()
        if args.command == 'collect-claude':
            from .claude_code import collect
            hook = json.loads(sys.stdin.read(65536))
            result = collect(hook, collector)
            delivery = collector.flush()
            if result['skipped'] or delivery.get('errors'):
                print(json.dumps({**result, **delivery}), file=sys.stderr)
            return
        if args.check:
            print(collector.check_connection()['message'])
            return
        from .mcp import run
        sys.stdin.reconfigure(encoding='utf-8')
        sys.stdout.reconfigure(encoding='utf-8')
        run(sys.stdin, sys.stdout, collector)
    except (ValueError, OSError) as error:
        # Error text from filesystem APIs can contain private paths.
        message = str(error) if isinstance(error, ReportingError) else 'Setup failed. Check token, URL, queue permissions and hook input.'
        print(message, file=sys.stderr)
        raise SystemExit(0 if args.command == 'collect-claude' else 1)


if __name__ == '__main__':
    main()
