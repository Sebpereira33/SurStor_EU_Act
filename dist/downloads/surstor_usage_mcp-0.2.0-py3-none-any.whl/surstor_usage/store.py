from contextlib import contextmanager
import json
from collections import defaultdict
from datetime import datetime,timezone,timedelta
from decimal import Decimal
from pathlib import Path
import sqlite3
from .model import canonical,validate
class Conflict(ValueError): pass
class Capacity(ValueError): pass
class Store:
    def __init__(self,path):
        self.path=str(path); Path(path).parent.mkdir(parents=True,exist_ok=True)
        with self.connect() as db:
            db.execute('PRAGMA journal_mode=WAL')
            db.execute('CREATE TABLE IF NOT EXISTS events(workspace TEXT,id TEXT,device TEXT,occurred TEXT,body TEXT,PRIMARY KEY(workspace,id))')
            db.execute('CREATE INDEX IF NOT EXISTS events_time ON events(workspace,occurred)')
    @contextmanager
    def connect(self):
        db=sqlite3.connect(self.path,timeout=15)
        try:
            with db: yield db
        finally: db.close()
    def ingest(self,workspace,device,event):
        event=validate(event); body=canonical(event)
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            old=db.execute('SELECT device,body FROM events WHERE workspace=? AND id=?',(workspace,event['event_id'])).fetchone()
            if old:
                if old!=(device,body): raise Conflict('Event ID already has different metadata')
                return False
            if db.execute('SELECT COUNT(*) FROM events WHERE workspace=?',(workspace,)).fetchone()[0]>=100000: raise Capacity('Preview capacity reached')
            db.execute('INSERT INTO events VALUES(?,?,?,?,?)',(workspace,event['event_id'],device,event['occurred_at'],body))
        return True
    def events(self,workspace,days=30,provider=None,model=None,integration=None):
        cutoff=(datetime.now(timezone.utc)-timedelta(days=days)).isoformat().replace('+00:00','Z')
        with self.connect() as db: rows=[json.loads(row[0]) for row in db.execute('SELECT body FROM events WHERE workspace=? AND occurred>=? ORDER BY occurred DESC',(workspace,cutoff))]
        return [e for e in rows if all(value is None or e[key]==value for key,value in [('provider',provider),('model',model),('integration',integration)])]
    def delete(self,workspace):
        with self.connect() as db: db.execute('DELETE FROM events WHERE workspace=?',(workspace,))
    def summary(self,workspace,days=30,provider=None,model=None,integration=None):
        all_events=self.events(workspace,days)
        choices=dict(models=[dict(provider=p,model=m) for p,m in sorted({(e['provider'],e['model']) for e in all_events})],integrations=sorted({e['integration'] for e in all_events}))
        events=[e for e in all_events if all(value is None or e[key]==value for key,value in [('provider',provider),('model',model),('integration',integration)])]
        activity={}
        for e in events:
            activity.setdefault(e['integration'],e['occurred_at'])
        models={}; daily=defaultdict(int); statuses=defaultdict(int); costs=defaultdict(Decimal); missing=0
        for e in events:
            key=(e['provider'],e['model'],e['integration'])
            row=models.setdefault(key,dict(provider=key[0],model=key[1],integration=key[2],events=0,input_tokens=0,output_tokens=0,input_known=0,output_known=0,unknown_counts=0))
            row['events']+=1; statuses[e['usage_status']]+=1
            row['input_tokens']+=e['input_tokens'] or 0; row['output_tokens']+=e['output_tokens'] or 0
            row['input_known']+=int(e['input_tokens'] is not None); row['output_known']+=int(e['output_tokens'] is not None)
            row['unknown_counts']+=int(e['input_tokens'] is None or e['output_tokens'] is None)
            daily[e['occurred_at'][:10]]+=(e['input_tokens'] or 0)+(e['output_tokens'] or 0)
            if e['cost'] is None: missing+=1
            else: costs[(e['cost']['currency'],e['cost']['kind'])]+=Decimal(e['cost']['amount'])
        return dict(choices=choices,activity=[dict(integration=k,last_event_at=v) for k,v in sorted(activity.items())],events=len(events),days=days,input_tokens=sum(x['input_tokens'] for x in models.values()),output_tokens=sum(x['output_tokens'] for x in models.values()),input_known=sum(x['input_known'] for x in models.values()),output_known=sum(x['output_known'] for x in models.values()),unknown_counts=sum(x['unknown_counts'] for x in models.values()),unpriced_events=missing,statuses=dict(statuses),models=list(models.values()),daily=[dict(date=k,tokens=v) for k,v in sorted(daily.items())],costs=[dict(currency=k[0],kind=k[1],amount=format(v,'.6f')) for k,v in sorted(costs.items())])
