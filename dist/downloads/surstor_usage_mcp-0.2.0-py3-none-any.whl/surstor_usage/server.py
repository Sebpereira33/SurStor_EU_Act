"""Development server. Production ingress requires TLS, rate limits and managed auth."""
import hashlib,json
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit,parse_qs
from .model import MAX_BODY,InvalidEvent
from .store import Store,Conflict,Capacity
WEB=Path(__file__).parent/'web'
def credentials(config):
    result={}; workspaces=set(); devices=set()
    for w in config['workspaces']:
        if w['id'] in workspaces: raise ValueError('Duplicate workspace')
        workspaces.add(w['id']); pairs=[(w['dashboard_token'],'dashboard',None)]
        for d in w['devices']:
            if d['id'] in devices: raise ValueError('Duplicate device')
            devices.add(d['id']); pairs.append((d['token'],'device',d['id']))
        for token,role,device in pairs:
            if not isinstance(token,str) or len(token)<32: raise ValueError('Use strong random credentials')
            digest=hashlib.sha256(token.encode()).digest()
            if digest in result: raise ValueError('Credentials must be unique')
            result[digest]=(w['id'],role,device)
    return result

def make_server(config,database,host='127.0.0.1',port=8790):
    auth=credentials(config); store=Store(database)
    class Handler(BaseHTTPRequestHandler):
        def setup(self):
            super().setup(); self.connection.settimeout(10)
        def log_message(self,*_): pass
        def send(self,status,value,kind='application/json'):
            data=json.dumps(value,allow_nan=False).encode() if kind=='application/json' else value
            self.send_response(status); self.send_header('Content-Type',kind); self.send_header('Content-Length',str(len(data)))
            self.send_header('Cache-Control','no-store'); self.send_header('X-Content-Type-Options','nosniff'); self.send_header('Referrer-Policy','no-referrer')
            self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'")
            self.end_headers(); self.wfile.write(data)
        def principal(self,role):
            header=self.headers.get('Authorization',''); token=header[7:] if header.startswith('Bearer ') else ''
            principal=auth.get(hashlib.sha256(token.encode()).digest())
            if not principal or principal[1]!=role:
                self.send(401,{'error':'Unauthorized'}); return None
            return principal
        def do_GET(self):
            path=urlsplit(self.path)
            if path.path in ('/','/app.js','/style.css'):
                name={'/':'index.html','/app.js':'app.js','/style.css':'style.css'}[path.path]
                kind={'/':'text/html; charset=utf-8','/app.js':'application/javascript','/style.css':'text/css'}[path.path]
                return self.send(200,(WEB/name).read_bytes(),kind)
            if path.path=='/health': return self.send(200,{'status':'ok'})
            if path.path not in ('/api/summary','/api/export'): return self.send(404,{'error':'Not found'})
            p=self.principal('dashboard')
            if not p: return
            try:
                query=parse_qs(path.query); days=int(query.get('days',['30'])[0])
                if not 1<=days<=365 or set(query)-{'days','provider','model','integration'} or any(len(v)!=1 or len(v[0])>128 for k,v in query.items() if k!='days'): raise ValueError()
            except ValueError: return self.send(400,{'error':'Invalid date range'})
            filters={k:query[k][0] for k in ('provider','model','integration') if k in query}
            self.send(200,store.summary(p[0],days,**filters) if path.path=='/api/summary' else {'events':store.events(p[0],days,**filters)})
        def do_POST(self):
            if self.path!='/api/events': return self.send(404,{'error':'Not found'})
            p=self.principal('device')
            if not p: return
            try:
                length=int(self.headers.get('Content-Length','0'))
                if not 0<length<=MAX_BODY or self.headers.get('Transfer-Encoding') or self.headers.get('Content-Encoding') or self.headers.get_content_type()!='application/json': raise InvalidEvent()
                body=self.rfile.read(length)
                if len(body)!=length: raise InvalidEvent()
                created=store.ingest(p[0],p[2],json.loads(body))
                self.send(201 if created else 200,{'accepted':True,'duplicate':not created})
            except Conflict: self.send(409,{'error':'Event ID conflict'})
            except Capacity: self.send(507,{'error':'Preview capacity reached'})
            except (ValueError,TypeError,KeyError,RecursionError): self.send(422,{'error':'Invalid metadata; no event accepted'})
            except Exception: self.send(503,{'error':'Storage unavailable; retry the same event ID'})
        def do_DELETE(self):
            if self.path!='/api/events': return self.send(404,{'error':'Not found'})
            p=self.principal('dashboard')
            if not p: return
            if self.headers.get('X-Confirm-Delete')!='all-workspace-events': return self.send(400,{'error':'Explicit confirmation required'})
            store.delete(p[0]); self.send(200,{'deleted':True})
    return ThreadingHTTPServer((host,port),Handler)
