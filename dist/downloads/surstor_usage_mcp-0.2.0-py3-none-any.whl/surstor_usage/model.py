"""Strict metadata boundary; no arbitrary content or extension fields."""
from datetime import datetime, timezone, timedelta
from decimal import Decimal
import json
import re
import uuid
MAX_BODY=16384
FIELDS={"version","event_id","occurred_at","provider","model","integration","usage_source","usage_status","input_tokens","output_tokens","cache_read_tokens","cache_write_tokens","cost","project_id"}
COUNTS=("input_tokens","output_tokens","cache_read_tokens","cache_write_tokens")
SOURCES={"provider_response","harness_event","inference_server","manual"}
STATUSES={"reported","estimated","incomplete","unknown"}
SECRET=re.compile(r"(?:sk-|gh[pousr]_|github_pat_|xox[baprs]-|AKIA|Bearer|BEGIN.*KEY)",re.I)
class InvalidEvent(ValueError): pass

def identifier(value):
    if not isinstance(value,str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}",value) or SECRET.search(value) or '://' in value or '..' in value or re.match(r'^[A-Za-z]:/',value): raise InvalidEvent('Invalid identifier')
    return value

def canonical(value): return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)

def validate(event):
    if not isinstance(event,dict) or not set(event)<=FIELDS or not (FIELDS-{'project_id','cost','cache_read_tokens','cache_write_tokens'})<=set(event): raise InvalidEvent('Only documented metadata fields are accepted')
    if type(event['version']) is not int or event['version']!=1: raise InvalidEvent('Unsupported version')
    out=dict(event)
    for key in ('event_id','project_id'):
        if key in out:
            if not isinstance(out[key],str): raise InvalidEvent(f'{key}: must be a UUID')
            try: out[key]=str(uuid.UUID(out[key]))
            except ValueError: raise InvalidEvent(f'{key}: must be a UUID') from None
    for key in ('provider','model','integration'):
        try: identifier(out[key])
        except InvalidEvent: raise InvalidEvent(f'{key}: invalid identifier; see the event contract') from None
    try:
        if not isinstance(out['occurred_at'],str) or len(out['occurred_at'])>40: raise ValueError()
        timestamp=datetime.fromisoformat(out['occurred_at'].replace('Z','+00:00'))
        if timestamp.tzinfo is None or timestamp>datetime.now(timezone.utc)+timedelta(minutes=5): raise ValueError()
        out['occurred_at']=timestamp.astimezone(timezone.utc).isoformat(timespec='microseconds').replace('+00:00','Z')
    except (ValueError,TypeError): raise InvalidEvent('occurred_at: use a timezone-aware ISO timestamp within five minutes of current time') from None
    if not isinstance(out['usage_source'],str) or out['usage_source'] not in SOURCES: raise InvalidEvent('usage_source: must be provider_response, harness_event, inference_server or manual')
    if not isinstance(out['usage_status'],str) or out['usage_status'] not in STATUSES: raise InvalidEvent('usage_status: must be reported, estimated, incomplete or unknown')
    for key in COUNTS:
        value=out.setdefault(key,None)
        if value is not None and (type(value) is not int or not 0<=value<=1000000000): raise InvalidEvent(f'{key}: must be null or an integer from 0 to 1000000000')
    if out['input_tokens'] is not None and sum(out[k] or 0 for k in ('cache_read_tokens','cache_write_tokens'))>out['input_tokens']: raise InvalidEvent('input_tokens: cache counts exceed inclusive input')
    if out['usage_status']=='reported' and any(out[k] is None for k in ('input_tokens','output_tokens')): raise InvalidEvent('Reported usage needs counts')
    if out['usage_status']=='unknown' and any(out[k] is not None for k in COUNTS): raise InvalidEvent('Unknown usage must not invent counts')
    cost=out.setdefault('cost',None)
    if cost is not None:
        if not isinstance(cost,dict) or set(cost)!={'amount','currency','kind','pricing_version'}: raise InvalidEvent('Invalid cost fields')
        if not isinstance(cost['amount'],str) or not re.fullmatch(r"[0-9]{1,9}(?:\.[0-9]{1,6})?",cost['amount']): raise InvalidEvent('Invalid cost')
        if not isinstance(cost['currency'],str) or not re.fullmatch(r'[A-Z]{3}',cost['currency']): raise InvalidEvent('Invalid currency')
        if not isinstance(cost['kind'],str) or cost['kind'] not in {'provider_reported','estimated'}: raise InvalidEvent('Invalid cost kind')
        if cost['kind']=='estimated' or cost['pricing_version'] is not None: identifier(cost['pricing_version'])
        out['cost']={**cost,'amount':format(Decimal(cost['amount']),'.6f')}
    if len(canonical(out).encode())>MAX_BODY: raise InvalidEvent('Metadata too large')
    return out

EVENT_SCHEMA={'type':'object','additionalProperties':False,
 'required':['version','event_id','occurred_at','provider','model','integration','usage_source','usage_status','input_tokens','output_tokens'],
 'properties':{'version':{'type':'integer','const':1},'event_id':{'type':'string','format':'uuid'},'project_id':{'type':'string','format':'uuid'},'occurred_at':{'type':'string','format':'date-time'},
 **{k:{'type':'string','maxLength':128} for k in ('provider','model','integration')},
 'usage_source':{'type':'string','enum':sorted(SOURCES)},'usage_status':{'type':'string','enum':sorted(STATUSES)},
 **{k:{'type':['integer','null'],'minimum':0,'maximum':1000000000} for k in COUNTS},
 'cost':{'type':['object','null'],'additionalProperties':False,'required':['amount','currency','kind','pricing_version'],'properties':{'amount':{'type':'string'},'currency':{'type':'string'},'kind':{'enum':['estimated','provider_reported']},'pricing_version':{'type':['string','null']}}}}}

# JSON Schema expresses structural rules. Cache sums and clock skew are enforced
# by validate() and documented in the downloadable event contract.
for name in ('provider','model','integration'):
    EVENT_SCHEMA['properties'][name].update(minLength=1,pattern=r'^[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}$')
cost_fields=EVENT_SCHEMA['properties']['cost']['properties']
cost_fields['amount']['pattern']=r'^[0-9]{1,9}(\.[0-9]{1,6})?$'
cost_fields['currency']['pattern']=r'^[A-Z]{3}$'
cost_fields['pricing_version'].update(maxLength=128)
EVENT_SCHEMA['properties']['input_tokens']['description']='Includes cache reads and writes; their sum cannot exceed this count.'
EVENT_SCHEMA['properties']['occurred_at']['description']='Timezone required; up to six fractional digits; at most five minutes in the future.'
EVENT_SCHEMA['allOf']=[
    {'if':{'properties':{'usage_status':{'const':'reported'}}},
     'then':{'properties':{name:{'type':'integer'} for name in ('input_tokens','output_tokens')}}},
    {'if':{'properties':{'usage_status':{'const':'unknown'}}},
     'then':{'properties':{name:{'type':'null'} for name in COUNTS}}}
]
